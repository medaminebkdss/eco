<?php
require_once 'db.php';

$format = isset($_GET['format']) ? $_GET['format'] : 'html';

// جلب جميع المنتجات
$sql = "SELECT * FROM products ORDER BY created_at DESC";
$result = $conn->query($sql);

if (!$result) {
    if ($format === 'json') {
        json_response(['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $conn->error]);
    } else {
        echo '<div class="no-products">خطأ في قاعدة البيانات</div>';
    }
    exit;
}

if ($format === 'json') {
    $products = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $row['images'] = json_decode($row['images'], true);
            $products[] = $row;
        }
    }
    json_response(['success' => true, 'products' => $products]);
} else {
    // إرجاع HTML
    $html = '';
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $images = json_decode($row['images'], true);
            $main_image = !empty($images) ? $images[0] : 'https://placehold.co/300x200?text=No+Image';
            
            $discount_percent = 0;
            if ($row['original_price'] > 0) {
                $discount_percent = round((($row['original_price'] - $row['discounted_price']) / $row['original_price']) * 100);
            }
            
            $html .= '
            <div class="product-card" data-product-id="' . $row['id'] . '">
                <div class="product-image">
                    <img src="' . htmlspecialchars($main_image) . '" alt="' . htmlspecialchars($row['name']) . '">
                    ' . ($discount_percent > 0 ? '<span class="discount-badge">-' . $discount_percent . '%</span>' : '') . '
                </div>
                <div class="product-info">
                    <h3 class="product-name">' . htmlspecialchars($row['name']) . '</h3>
                    <div class="product-prices">
                        ' . ($row['original_price'] != $row['discounted_price'] ? 
                            '<span class="original-price">' . number_format($row['original_price'], 0) . ' دج</span>' : '') . '
                        <span class="discounted-price">' . number_format($row['discounted_price'], 0) . ' دج</span>
                    </div>
                    <button class="btn btn-primary order-btn" 
                            data-product-id="' . $row['id'] . '"
                            data-product-name="' . htmlspecialchars($row['name']) . '"
                            data-product-price="' . $row['discounted_price'] . '">
                        أطلب الآن
                    </button>
                </div>
            </div>';
        }
    } else {
        $html = '<div class="no-products">لا توجد منتجات متاحة حالياً</div>';
    }
    
    echo $html;
}

$conn->close();
?>
