<?php
require_once 'db.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'طريقة الطلب غير صحيحة'], 405);
}

// التحقق من البيانات المطلوبة
if (empty($_POST['customer_name']) || empty($_POST['phone']) || empty($_POST['address']) || empty($_POST['product_id']) || empty($_POST['wilaya'])) {
    json_response(['success' => false, 'message' => 'جميع الحقول مطلوبة']);
}

$customer_name = sanitize_input($_POST['customer_name']);
$phone = sanitize_input($_POST['phone']);
$address = sanitize_input($_POST['address']);
$notes = isset($_POST['notes']) ? sanitize_input($_POST['notes']) : '';
$product_id = intval($_POST['product_id']);
$wilaya_code = sanitize_input($_POST['wilaya']);
$wilaya_name = isset($_POST['wilaya_name']) ? sanitize_input($_POST['wilaya_name']) : '';
$shipping_cost = floatval($_POST['shipping_cost']);
$total_cost = floatval($_POST['total_cost']);

// إذا لم يتم إرسال اسم الولاية، جلبه من قاعدة البيانات
if (empty($wilaya_name)) {
    $wilaya_sql = "SELECT wilaya_name FROM shipping_rates WHERE wilaya_code = ?";
    $wilaya_stmt = $conn->prepare($wilaya_sql);
    $wilaya_stmt->bind_param("s", $wilaya_code);
    $wilaya_stmt->execute();
    $wilaya_result = $wilaya_stmt->get_result();
    
    if ($wilaya_result->num_rows > 0) {
        $wilaya_row = $wilaya_result->fetch_assoc();
        $wilaya_name = $wilaya_row['wilaya_name'];
    } else {
        $wilaya_name = $wilaya_code; // استخدام الكود كبديل
    }
    $wilaya_stmt->close();
}

// جلب معلومات المنتج
$product_sql = "SELECT name, discounted_price FROM products WHERE id = ?";
$product_stmt = $conn->prepare($product_sql);
$product_stmt->bind_param("i", $product_id);
$product_stmt->execute();
$product_result = $product_stmt->get_result();

if ($product_result->num_rows === 0) {
    json_response(['success' => false, 'message' => 'المنتج غير موجود']);
}

$product = $product_result->fetch_assoc();
$product_stmt->close();

// إدراج الطلب مع معلومات الشحن
$sql = "INSERT INTO orders (customer_name, phone, address, notes, product_id, product_name, product_price, wilaya, shipping_cost, total_cost) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("ssssissddd", $customer_name, $phone, $address, $notes, $product_id, $product['name'], $product['discounted_price'], $wilaya_name, $shipping_cost, $total_cost);
    
    if ($stmt->execute()) {
        json_response(['success' => true, 'message' => 'تم إرسال طلبكم بنجاح! طلبيتكم قيد المراجعة وسنتصل بكم خلال 24 ساعة لتأكيد الطلب.']);
    } else {
        json_response(['success' => false, 'message' => 'خطأ في إرسال الطلب: ' . $stmt->error]);
    }
    
    $stmt->close();
} else {
    json_response(['success' => false, 'message' => 'خطأ في إعداد الاستعلام: ' . $conn->error]);
}

$conn->close();
?>
